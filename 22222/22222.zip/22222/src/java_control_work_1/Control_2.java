package java_control_work_1;

public class Control_2 {

    public static void main(String[] args) {

        double S, a, b, c, p;

        System.out.print("Semiperimeter : ");

        p = 0.5 * (a+b+c);
        
        System.out.println(p);

    }
}
